package com.example.form2.adaptador;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.form2.R;
import com.example.form2.usuario.Tarea;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Adaptador extends RecyclerView.Adapter<Adaptador.ViewHolder>  {

    private ArrayList<Tarea> datos = new ArrayList<>();


    @NonNull
    @Override
    public Adaptador.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tarea, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adaptador.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder  {


        TextView txt_titulo, txt_nombre, txt_cat, txt_estado;
        ImageView img_tarea;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_cat = itemView.findViewById(R.id.txt_cat);
            txt_titulo = itemView.findViewById(R.id.txt_titulo);
            txt_nombre = itemView.findViewById(R.id.txt_nombre);
            txt_estado = itemView.findViewById(R.id.txt_estado);

            img_tarea = itemView.findViewById(R.id.img_tarea);

        }
        public void bind(Tarea dato) {
            txt_cat.setText(dato.getCategoria());
            txt_nombre.setText(dato.getNombre());
            txt_estado.setText(dato.getEstado());

            Picasso.get().load(dato.getImg()).into(img_tarea);
        }

    }
}
